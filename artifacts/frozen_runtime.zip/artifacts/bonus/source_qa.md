# Kiểm chứng nguồn bonus — trước selection/test

Nguồn: *Machine Learning cơ bản*, Vũ Hữu Tiệp, 27/03/2018. Số trang luôn là
trang PDF vật lý; không suy một offset chung cho phần lời nói đầu và thân sách.
PDF hash và 400 ảnh hash đã kiểm trong `source_audit.json`. Ảnh được render trực tiếp
từ PDF bằng PyMuPDF, gồm cả vector graphics. Chưa có human audit độc lập.

## Phạm vi đã kiểm tra

- Contact sheet các trang bảng: 11,47,99,142,177,315,367,372.
- Sơ đồ/biểu đồ: 54,60,61,63,113,129,143,160,174,186,194,195,206,210,211,
  230,240,249,260,264,272,281,282,295,296,332,342,353,366,368,373,380,388.
- Mở riêng độ phân giải gốc các trang cần đọc nhãn/số nhỏ: 47,61,63,99,143,160,
  177,195,211,235,249,264,272,273,276,282,372,380.
- Đối chiếu text nguồn với render cho 6,11,118,133,135,136,287. Mẫu render rải toàn
  sách: 25,50,75,100,125,150,175,200,225,250,275,300,325,350,375,400.
  Trang mở đầu phần/ít text vẫn được giữ, không tính thành nội dung đã OCR.
- Đây là QA các trang được liệt kê và kiểm hash toàn bộ, không phải tuyên bố đọc tay
  toàn bộ 400 trang hay chứng minh mọi native equation được trích đúng.

## Quan sát có ảnh hưởng đến benchmark/đánh giá

| Trang/vùng | Đối chiếu bản gốc | Cách xử lý |
|---|---|---|
| p47/Bảng2.1 | Gradient có A+Aᵀ; native text có thể phá bố cục mũ/chuyển vị | Dùng ảnh để kiểm các ô, không thay bằng 2A khi chưa có giả định đối xứng |
| p99/Bảng7.1 | Ô 170cm là72kg, mảng Python bên dưới là62 | Câu hỏi ghi rõ lấy ô bảng; không tự sửa sách theo code |
| p143/Hình11.1 | 3 văn bản B và1 N; hệ số prior3/4 và1/4 | B0/bd04 bị chấm fail vì tự đổi thành4/5,1/5 |
| p63/Hình3.4a | Cặp (10,10), không có đường (5,5) | Sửa lỗi soạn câu dev bd07; lưu bản cũ |
| p264/mục20.3 | Dưới3% là thông tin mất đi; bộ nhớ dùng công thức20.23 | Sửa gold dev bd12 thành69.47% kèm giả định byte; không sửa câu hỏi để che lỗi |
| p195/Hình15.3 | Nhóm cuối z=(3,3,1), a=(.486,.486,.027) | Giữ số in trên hình; không chấm tổng làm tròn .999 thành sai |
| p211/Hình16.6b | Trục dọc Training error rate; đường liền dừng khoảng epoch6 | Sửa draft bt13 trước mọi test: hỏi thời điểm đạt.25, không hỏi cost tại epoch20 |
| p249/Hình19.1 | Khối trong sơ đồ là Xᵀ M×K; caption có cách viết X dễ nhầm | Câu hỏi chỉ rõ đọc nhãn trên khối sơ đồ |
| p372/B1-bd03 bbox | Crop y600–720 cắt mất hàng poly | Answer đúng nhưng citation fail; bản review trước crop được lưu history |

Các quan sát QA trên được ghi trước model test/selection; hiện test V8 đã hoàn tất21/30.
Không dùng QA test này để chọn query/filter/prompt/model. Chỉ sửa lỗi soạn nguồn/gold của bản draft trước khi khóa; thay đổi pipeline
(mẫu số, bbox guidance, parser panel suffix) xuất phát từ lỗi/câu dev.

## Độ phủ và giới hạn

400 trang đều có native text/layout và ảnh150dpi; 14 trang dưới100 ký tự vẫn có ảnh.
Không có trang lỗi render bị bỏ. Không thực hiện OCR hoặc caption bằng model trên toàn
sách. Nội dung không có caption/text tìm kiếm được có thể bị lexical retrieval bỏ lỡ,
dù ảnh nguyên trang đã ở index. Native math/reading order không tự được coi là đúng.
Audit cuối đếm20/30 câu test có reference hình/bảng theo parser (sửa số18/30 ghi chú cũ,
không thay câu hỏi/gold/kết quả); benchmark thiên về tra cứu nguồn có
locator, chưa chứng minh khả năng discovery mọi câu hỏi tự do.

Các câu thiếu evidence có literal full-book checks ở `source_audit.json` và kiểm mục thí
nghiệm cụ thể ở gold. GPU có xuất hiện ởp116 nhưng không có model GPU/thời gian run MNIST
được hỏi trong dev bd17; không suy “GPU không xuất hiện ở bất cứ đâu”. Không dùng thất bại top-k để kết luận vắng evidence.

Các mục history nói trên hiện nằm trong ZIP local ignored, xem `trial_registry.json`
và `../cleanup_manifest.json`; không cần giữ các bản trùng rời trong hồ sơ báo cáo.
