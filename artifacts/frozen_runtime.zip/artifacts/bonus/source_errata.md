# Source erratum — dev bd09

Đối chiếu lại ảnh nguyên trang PDF366 ngày2026-11-17 trước selection/test:
Hình27.5 có bốn panel C=0.100000,1,10,100. Gold cũ ghi nhầm panel đầu0.00001.
Sửa locator thành0.1, expected_answer về xu hướng không đổi; benchmark/protocol/code/config
V7 được giữ trong history trước khi tạo V8. Runtime chỉ nhận id/question, không nhận locator.

Rationale cũ của V4 đã nhầm khi trừ claim C=.1. Review gốc được lưu nguyên tại
`artifacts/bonus/history/review_v4_before_source_erratum.json` bên trong ZIP local
`.archive/day07_trials_before_final_report_20261117.zip`; review sau đính chính cũng
được giữ trong ZIP, vẫn fail vì
đáp án nhập nhằng điểm nằm trong biên với điểm phân lớp sai phía đường quyết định.
V7 cũng có nhập nhằng này nên fail theo yêu cầu mọi claim phải được nguồn hỗ trợ.
Không sửa câu trả lời model, trace hay dùng dữ liệu test để thay pipeline.
